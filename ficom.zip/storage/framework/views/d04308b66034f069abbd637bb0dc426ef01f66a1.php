
<?php $__env->startSection('content'); ?>

<?php
    $hAT = $estudiante->hasApoderadoTitular();  //hasApoderadoTitular
    $hAS = $estudiante->hasApoderadoSuplente(); //hasApoderadoSuplente
?>

<div class="container">
    <div class="buttons mb-4">
        <a href="<?php echo e(route('estudiante.pagos', $estudiante->id)); ?>" class="btn btn-primary">Ver historial de pago</a>
        <a href="<?php echo e(route('estudiante.beca.edit', $estudiante->id)); ?>" class="btn btn-primary">Administrar beca</a>
    </div>

    <form method="POST" action="<?php echo e(route('estudiante.update', $estudiante->id)); ?>" class="mt-3 row">
        <?php echo csrf_field(); ?>
        <h2>Estudiante</h2>
        <div class="form-group mb-3 col-md-4 col-6">
            <label for="apellidos" class="form-label">Apellidos</label>
            <input type="text" name="apellidos" id="apellidos"  class="form-control <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('apellidos') ? old('apellidos') : $estudiante->apellidos); ?>" disabled>

            <?php $__errorArgs = ['apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-md-4 col-6">
            <label for="nombres" class="form-label">Nombres</label>
            <input type="text" name="nombres" id="nombres" class="form-control <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('nombres') ? old('nombres') : $estudiante->nombres); ?>" disabled>

            <?php $__errorArgs = ['nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-md-4 col-6">
            <label for="run" class="form-label">RUN</label>
            <input type="text" name="run" id="run" class="form-control <?php $__errorArgs = ['run'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('run') ? old('run') : $estudiante->rut . '-' . $estudiante->dv); ?>" disabled>

            <?php $__errorArgs = ['run'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-md-4 col-6">
            <label for="email_institucional" class="form-label">Correo Institucional</label>
            <input type="email" name="email_institucional" id="email_institucional" class="form-control <?php $__errorArgs = ['email_institucional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email_institucional') ? old('email_institucional') : $estudiante->email_institucional); ?>" disabled>

            <?php $__errorArgs = ['email_institucional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-md-4 col-6">
            <label for="nivel" class="form-label">Nivel</label>
            <select id="nivel" name="nivel" id="nivel" class="form-control form-select <?php $__errorArgs = ['nivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>
                <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($curso->id); ?>" <?php if($estudiante->curso_id == $curso->id): echo 'selected'; endif; ?>><?php echo e($curso->curso . '-' . $curso->paralelo); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <?php $__errorArgs = ['nivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-md-4 col-6">
            <label for="prioridad" class="form-label">Prioridad</label>
            <select name="prioridad" id="prioridad" class="form-control form-select <?php $__errorArgs = ['prioridad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" disabled>
                <option value="alumno regular" <?php if($estudiante->prioridad == "alumno regular"): echo 'selected'; endif; ?>>Alumno regular</option>
                <option value="nuevo prioritario" <?php if($estudiante->prioridad == "nuevo prioritario"): echo 'selected'; endif; ?>>Nuevo prioritario</option>
                <option value="prioritario" <?php if($estudiante->prioridad == "prioritario"): echo 'selected'; endif; ?>>Prioritario</option>
            </select>

            <?php $__errorArgs = ['prioridad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="apoderado-title mt-3 mb-1">
            <h2>Apoderado</h2>
            <?php if($hAT): ?>
            <div>
                <button type="button" class="btn btn-sm btn-danger del" onclick="deleteSubmit('deleteApoderado')">Eliminar</button>
            </div>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3 col-6 col-md-6">
            <label for="a_nombres" class="form-label">Nombres</label>
            <input type="text" id="a_nombres" name="a_nombres" class="form-control <?php $__errorArgs = ['a_nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('a_nombres') ? old('a_nombres') : ($hAT ? $estudiante->apoderado_titular->nombres : '')); ?>" disabled
            >

            <?php $__errorArgs = ['a_nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-6">
            <label for="a_apellidos" class="form-label">Apellidos</label>
            <input type="text" id="a_apellidos" name="a_apellidos" class="form-control <?php $__errorArgs = ['a_apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('a_apellidos') ? old('a_apellidos') : ($hAT ? $estudiante->apoderado_titular->apellidos : '')); ?>" disabled
            >

            <?php $__errorArgs = ['a_apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-2">
            <label for="a_telefono" class="form-label">Teléfono</label>
            <input type="text" id="a_telefono" name="a_telefono" class="form-control <?php $__errorArgs = ['a_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('a_telefono') ? old('a_telefono') : ($hAT ? $estudiante->apoderado_titular->telefono : '')); ?>" disabled
            >

            <?php $__errorArgs = ['a_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-5">
            <label for="a_email" class="form-label">Correo Electrónico</label>
            <input type="email" id="a_email" name="a_email" class="form-control <?php $__errorArgs = ['a_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('a_email') ? old('a_email') : ($hAT ? $estudiante->apoderado_titular->email : '')); ?>" disabled
            >

            <?php $__errorArgs = ['a_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-5">
            <label for="a_direccion" class="form-label">Dirección</label>
            <input type="text" id="a_direccion" name="a_direccion" class="form-control <?php $__errorArgs = ['a_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('a_direccion') ? old('a_direccion') : ($hAT ? $estudiante->apoderado_titular->direccion : '')); ?>" disabled
            >

            <?php $__errorArgs = ['a_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="apoderado-title mt-3 mb-1">
            <h2>Apoderado suplente</h2>
            <?php if($hAS): ?>
            <div>
                <button type="button" class="btn btn-sm btn-danger del" onclick="deleteSubmit('deleteApoderadoSuplente')">Eliminar</button>
            </div>
            <?php endif; ?>
        </div>
        <div class="form-group mb-3 col-6">
            <label for="sub_nombres" class="form-label">Nombres</label>
            <input type="text" id="sub_nombres" name="sub_nombres" class="form-control <?php $__errorArgs = ['sub_nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('sub_nombres') ? old('sub_nombres') : ($hAS ? $estudiante->apoderado_suplente->nombres : '')); ?>" disabled
            >

            <?php $__errorArgs = ['sub_nombres'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6">
            <label for="sub_apellidos" class="form-label">Apellidos</label>
            <input type="text" id="sub_apellidos" name="sub_apellidos" class="form-control <?php $__errorArgs = ['sub_apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('sub_apellidos') ? old('sub_apellidos') : ($hAS ? $estudiante->apoderado_suplente->apellidos : '')); ?>" disabled
            >

            <?php $__errorArgs = ['sub_apellidos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-2">
            <label for="sub_telefono" class="form-label">Teléfono</label>
            <input type="text" id="sub_telefono" name="sub_telefono" class="form-control <?php $__errorArgs = ['sub_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('sub_telefono') ? old('sub_telefono') : ($hAS ? $estudiante->apoderado_suplente->telefono : '')); ?>" disabled
            >

            <?php $__errorArgs = ['sub_telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-5">
            <label for="sub_email" class="form-label">Correo Electrónico</label>
            <input type="email" id="sub_email" name="sub_email" class="form-control <?php $__errorArgs = ['sub_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('sub_email') ? old('sub_email') : ($hAS ? $estudiante->apoderado_suplente->email : '')); ?>" disabled
            >

            <?php $__errorArgs = ['sub_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-5">
            <label for="sub_direccion" class="form-label">Dirección</label>
            <input type="text" id="sub_direccion" name="sub_direccion" class="form-control <?php $__errorArgs = ['sub_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                value="<?php echo e(old('sub_direccion') ? old('sub_direccion') : ($hAS ? $estudiante->apoderado_suplente->direccion : '')); ?>" disabled
            >

            <?php $__errorArgs = ['sub_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
        <?php if(auth()->user()->hasAnyRole('admin', 'matriculas')): ?>
            <div class="buttons">
                <button type="button" id="btn-editar" class="btn btn-secondary" onclick="editar()">Editar</button>
                <button type="button" id="btn-cancelar" class="btn btn-danger" onclick="cancelEditar()" hidden>Cancelar</button>
                <button type="submit" id="btn-enviar" class="btn btn-primary" hidden>Guardar</button>
            </div>
        <?php endif; ?>
    </form>

    <?php if($hAT): ?>
    <form method="post" action="<?php echo e(route('estudiante.apoderado.remove', ['id' => $estudiante->id, 'apoderado' => $estudiante->apoderado_titular->id])); ?>" id="deleteApoderado">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
    </form>
    <?php endif; ?>

    <?php if($hAS): ?>
    <form method="post" action="<?php echo e(route('estudiante.apoderado.remove', ['id' => $estudiante->id, 'apoderado' => $estudiante->apoderado_suplente->id])); ?>" id="deleteApoderadoSuplente">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
    </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        const btneditar = document.getElementById('btn-editar');
        const cancelar = document.getElementById('btn-cancelar');
        const enviar = document.getElementById('btn-enviar');
        const deleteBtns = document.getElementsByClassName('del');
    
        for(let btn of deleteBtns) btn.hidden = true;

        //Estudiante
        const apellidos = document.getElementById('apellidos');
        const nombres = document.getElementById('nombres');
        const run = document.getElementById('run');
        const email_institucional = document.getElementById('email_institucional');
        const nivel = document.getElementById('nivel');
        const prioridad = document.getElementById('prioridad');
        
        //Apoderado
        const a_nombres = document.getElementById('a_nombres');
        const a_apellidos = document.getElementById('a_apellidos');
        const a_telefono = document.getElementById('a_telefono');
        const a_email = document.getElementById('a_email');
        const a_direccion = document.getElementById('a_direccion');
        
        //Apoderado suplente
        const sub_nombres = document.getElementById('sub_nombres');
        const sub_apellidos = document.getElementById('sub_apellidos');
        const sub_telefono = document.getElementById('sub_telefono');
        const sub_email = document.getElementById('sub_email');
        const sub_direccion = document.getElementById('sub_direccion');
        
        function editar() {
            for(let btn of deleteBtns) btn.hidden = false;
            btneditar.hidden = true;
            cancelar.hidden = false;
            enviar.hidden = false;
            enableInput();
        }

        function cancelEditar() {
            for(let btn of deleteBtns) btn.hidden = true;
            btneditar.hidden = false;
            cancelar.hidden = true;
            enviar.hidden = true;
            disableInput();
        }

        function enableInput() {
            apellidos.disabled = false;
            nombres.disabled = false;
            run.disabled = false;
            email_institucional.disabled = false;
            nivel.disabled = false;
            prioridad.disabled = false;
            
            a_nombres.disabled = false;
            a_apellidos.disabled = false;
            a_telefono.disabled = false;
            a_email.disabled = false;
            a_direccion.disabled = false;
            
            sub_nombres.disabled = false;
            sub_apellidos.disabled = false;
            sub_telefono.disabled = false;
            sub_email.disabled = false;
            sub_direccion.disabled = false;
        }

        function disableInput() {
            apellidos.disabled = true;
            nombres.disabled = true;
            run.disabled = true;
            email_institucional.disabled = true;
            nivel.disabled = true;
            prioridad.disabled = true;

            a_nombres.disabled = true;
            a_apellidos.disabled = true;
            a_telefono.disabled = true;
            a_email.disabled = true;
            a_direccion.disabled = true;

            sub_nombres.disabled = true;
            sub_apellidos.disabled = true;
            sub_telefono.disabled = true;
            sub_email.disabled = true;
            sub_direccion.disabled = true;
        }
    </script>

    <?php if($errors->any()): ?>
    <script type="text/javascript">
        editar();
    </script>
    <?php endif; ?>

    <script src="<?php echo e(asset('js/components/delete.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\ficom_priv\resources\views/estudiante/perfil.blade.php ENDPATH**/ ?>