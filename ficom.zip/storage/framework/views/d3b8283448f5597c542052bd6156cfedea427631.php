
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-3">Becas</h2>
        
        <?php if(Auth::user()->hasAnyRole('contabilidad', 'admin')): ?>
            <div class="buttons">
                <a href="<?php echo e(route('beca.create')); ?>" class="btn btn-primary">Nueva beca</a>    
            </div>
        <?php endif; ?>

        <div class="row my-3">
            <?php $__currentLoopData = $becas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 mb-3">
                <div class="card beca">
                    <div>
                        <div class="nombre"><?php echo e($beca->nombre); ?></div>
                        <div class="descuento"><b>Descuento:</b> <?php echo e($beca->descuento); ?>%</div>
                        <div class="descripcion"><b>Descripción:</b> <?php echo e($beca->descripcion); ?></div>
                    </div>

                    <div class="buttons mt-2">
                        <a href="<?php echo e(route('beca.show', $beca->id)); ?>" class="btn btn-primary">Ver</a>
                        <?php if(Auth::user()->hasAnyRole('admin', 'contabilidad')): ?>
                            <a href="<?php echo e(route('beca.edit', $beca->id)); ?>" class="btn btn-primary">Editar</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\FICOM\resources\views/becas/index.blade.php ENDPATH**/ ?>