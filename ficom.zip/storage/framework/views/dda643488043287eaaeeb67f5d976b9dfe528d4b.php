
<?php $__env->startSection('content'); ?>

<div class="container card">
    <div class="row">
        <h2 class="mt-3">Información del estudiante</h2>
        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Estudiante</label>
            <p class="form-control"><?php echo e($estudiante->nombres . ' ' . $estudiante->apellidos); ?></p>
        </div>
        
        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Curso</label>
            <p class="form-control"><?php echo e($estudiante->curso->curso . '-' . $estudiante->curso->paralelo); ?></p>
        </div>
        
        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Prioridad</label>
            <p class="form-control flc"><?php echo e($estudiante->prioridad); ?></p>
        </div>

        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Beca</label>
            <p class="form-control"><?php echo e(!is_null($estudiante->beca) ? $estudiante->beca->nombre : 'Sin asignar'); ?></p>
        </div>

        <div class="buttons mb-3">
            <form action="<?php echo e(route('estudiante.beca.delete', $estudiante->id)); ?>" method="post">
                <?php echo method_field('delete'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger" <?php if(!$estudiante->beca): echo 'disabled'; endif; ?>>Remover beca</button>
            </form>
        </div>
    </div>

    <div class="row my-3">
        <h2>Asignar beca</h2>
        <?php $__currentLoopData = $becas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $beca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-4 mb-3">
            <div class="card beca">
                <div>
                    <div class="nombre"><?php echo e($beca->nombre); ?></div>
                    <div class="descuento"><b>Descuento:</b> <?php echo e($beca->descuento); ?>%</div>
                    <div class="descripcion"><b>Descripción:</b> <?php echo e($beca->descripcion); ?></div>
                </div>

                <div class="buttons mt-2">
                    <form action="<?php echo e(route('estudiante.beca.update', $estudiante->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="beca_id" value="<?php echo e($beca->id); ?>">
                        <button type="submit" class="btn btn-primary" <?php if(!is_null($estudiante->beca) && $estudiante->beca->id == $beca->id): echo 'disabled'; endif; ?>>Asignar beca</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\ficom_priv\resources\views/estudiante/beca.blade.php ENDPATH**/ ?>