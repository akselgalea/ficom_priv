
<?php $__env->startSection('content'); ?>
<?php
    $descuento = 0;
    if($estudiante->prioridad == 'prioritario') $descuento = 0;
    else if(! is_null($estudiante->beca)) $descuento = $estudiante->beca->descuento;
    $total = $estudiante->curso->arancel * ($descuento / 100);
    $mesAPagar = $estudiante->mesFaltante($estudiante->pagos_anio, $total);
?>

<div class="container card">
    <div class="row">
        <h2>Información del estudiante</h2>
        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Estudiante</label>
            <p class="form-control"><?php echo e($estudiante->nombres . ' ' . $estudiante->apellidos); ?></p>
        </div>
        
        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Curso</label>
            <p class="form-control"><?php echo e($estudiante->curso->curso . '-' . $estudiante->curso->paralelo); ?></p>
        </div>
        
        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Prioridad</label>
            <p class="form-control flc"><?php echo e($estudiante->prioridad); ?></p>
        </div>

        <div class="form-group mb-3 col-4">
            <label for="monto_mensual" class="form-label">Monto mensualidad</label>
            <p class="form-control"><?php echo e(toCLP($estudiante->curso->arancel)); ?></p>
        </div>
        <div class="form-group mb-3 col-4">
            <label for="beca" class="form-label">% Beca</label>
            <p class="form-control"><?php echo e(! is_null($estudiante->beca) ? $estudiante->beca->descuento : 'No tiene beca'); ?></p>
        </div>
        <div class="form-group mb-3 col-4">
            <label for="exencion" class="form-label">Total a pagar</label>
            <p class="form-control"><?php echo e(toCLP($total)); ?></p>
        </div>
    </div>
    <form method="POST" action="<?php echo e(route('pago.store', $estudiante->id)); ?>" id="formPago" class="mt-3 row">
        <?php echo csrf_field(); ?>
        <h2>Registrar pago</h2>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="mes" class="form-label">Mes</label>
            <select name="mes" class="form-control form-select <?php $__errorArgs = ['mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" selected disabled hidden>Selecciona una opción</option>
                <option value="matricula" <?php if($mesAPagar == 'matricula'): echo 'selected'; endif; ?>>Matrícula</option>
                <option value="marzo" <?php if($mesAPagar == 'marzo'): echo 'selected'; endif; ?>>Marzo</option>
                <option value="abril" <?php if($mesAPagar == 'abril'): echo 'selected'; endif; ?>>Abril</option>
                <option value="mayo" <?php if($mesAPagar == 'mayo'): echo 'selected'; endif; ?>>Mayo</option>
                <option value="junio" <?php if($mesAPagar == 'junio'): echo 'selected'; endif; ?>>Junio</option>
                <option value="julio" <?php if($mesAPagar == 'julio'): echo 'selected'; endif; ?>>Julio</option>
                <option value="agosto" <?php if($mesAPagar == 'agosto'): echo 'selected'; endif; ?>>Agosto</option>
                <option value="septiembre" <?php if($mesAPagar == 'septiembre'): echo 'selected'; endif; ?>>Septiembre</option>
                <option value="octubre" <?php if($mesAPagar == 'octubre'): echo 'selected'; endif; ?>>Octubre</option>
                <option value="noviembre" <?php if($mesAPagar == 'noviembre'): echo 'selected'; endif; ?>>Noviembre</option>
                <option value="diciembre" <?php if($mesAPagar == 'diciembre'): echo 'selected'; endif; ?>>Diciembre</option>
            </select>

            <?php $__errorArgs = ['mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="anio" class="form-label">Año</label>
            <select name="anio" class="form-control form-select <?php $__errorArgs = ['anio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" selected disabled hidden>Selecciona una opción</option>
                <option value="2022" <?php if(old('anio') == '2022' || now()->year == '2022'): echo 'selected'; endif; ?>>2022</option>
                <option value="2023" <?php if(old('anio') == '2023' || now()->year == '2023'): echo 'selected'; endif; ?>>2023</option>
                <option value="2024" <?php if(old('anio') == '2024' || now()->year == '2024'): echo 'selected'; endif; ?>>2024</option>
            </select>

            <?php $__errorArgs = ['anio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="documento" class="form-label">Documento</label>
            <select name="documento" class="form-control form-select <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" selected disabled hidden>Selecciona una opción</option>
                <option value="boleta"  <?php if(old('documento') == 'boleta'): echo 'selected'; endif; ?>>Boleta</option>
                <option value="recibo"  <?php if(old('documento') == 'recibo'): echo 'selected'; endif; ?>>Recibo</option>
            </select>

            <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="num_documento" class="form-label">N° Documento</label>
            <input type="number" name="num_documento" class="form-control <?php $__errorArgs = ['num_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('num_documento')); ?>">

            <?php $__errorArgs = ['num_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="fecha_pago" class="form-label">Fecha</label>
            <input type="date" name="fecha_pago" class="form-control <?php $__errorArgs = ['fecha_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value=<?php echo e(old('fecha_pago') ? old('fecha_pago') : today()); ?>>

            <?php $__errorArgs = ['fecha_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="valor" class="form-label">Valor</label>
            <input type="number" name="valor" class="form-control <?php $__errorArgs = ['valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('valor')); ?>">

            <?php $__errorArgs = ['valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-6 col-md-4">
            <label for="forma" class="form-label">Forma de pago</label>
            <select name="forma" class="form-control form-select <?php $__errorArgs = ['forma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="" selected disabled hidden>Selecciona una opción</option>
                <option value="efectivo" <?php if(old('forma') == 'efectivo'): echo 'selected'; endif; ?>>Efectivo</option>
                <option value="cheque" <?php if(old('forma') == 'cheque'): echo 'selected'; endif; ?>>Cheque</option>
                <option value="transferencia" <?php if(old('forma') == 'transferencia'): echo 'selected'; endif; ?>>Transferencia</option>
            </select>

            <?php $__errorArgs = ['forma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="form-group mb-3 col-12 col-md-6">
            <label for="observacion" class="form-label">Observaciones</label>
            <textarea name="observacion" class="form-control <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('observacion')); ?></textarea>

            <?php $__errorArgs = ['observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <button class="btn btn-primary">Enviar</button>
            <button type="button" class="btn btn-danger" onclick="cancelForm()">Cancelar</button>
        </div>
    </form>
</div>

<div class="container mt-3">
    <div class="tabla-pagos-container">
        <table class="tabla-pagos table table-bordered border-dark">
            <tbody>
                <tr class="datos-estudiante text-center">
                    <td colspan="2" style="width: 45%"><?php echo e($estudiante->apellidos); ?></td>
                    <td style="width: 30%"><?php echo e($estudiante->nombres); ?></td>
                    <td style="width: 130px"><?php echo e($estudiante->rut . '-' . $estudiante->dv); ?></td>
                    <td style="width: 60px"><?php echo e($estudiante->curso->curso . '-' . $estudiante->curso->paralelo); ?></td>
                    <td rowspan="2" style="width: 5ch"><?php echo e(now()->year); ?></td>
                </tr>
                <tr>
                    <td style="width: 10ch">Alumno:</td>
                    <td class="text-center">Apellido paterno y materno</td>
                    <td class="text-center">Nombres</td>
                    <td class="text-center">RUN</td>
                    <td class="text-center">NIVEL</td>
                </tr>
                <tr>
                    <td colspan="6">Nombre Apoderado: <?php echo e($estudiante->apoderado_titular ? $estudiante->apoderado_titular->nombres . ' ' . $estudiante->apoderado_titular->apellidos : ''); ?></td>
                </tr>
                <tr>
                    <td colspan="2">Teléfono: <?php echo e($estudiante->apoderado_titular ? $estudiante->apoderado_titular->telefono : ''); ?></td>
                    <td colspan="4">Correo Electrónico: <?php echo e($estudiante->apoderado_titular ? $estudiante->apoderado_titular->email : ''); ?></td>
                </tr>
            </tbody>
        </table>

        <table class="tabla-pagos table table-bordered border-dark">
            <thead>
              <tr>
                <th scope="col" style="width: 123px">Meses</th>
                <th scope="col" style="width: 123px">Documento</th>
                <th scope="col" style="width: 150px">N° Documento</th>
                <th scope="col" style="width: 120px">Fecha</th>
                <th scope="col" style="width: 130px">Valor</th>
                <th scope="col" style="width: 150px">Forma de pago</th>
                <th scope="col" style="width: auto">Observaciones</th>
              </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Matrícula</td>
                    <?php if(count($estudiante->pagos_anio['matricula']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['matricula']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['matricula']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['matricula']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Marzo</td>
                    <?php if(count($estudiante->pagos_anio['marzo']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['marzo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['marzo']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['marzo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Abril</td>
                    <?php if(count($estudiante->pagos_anio['abril']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['abril']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['abril']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['abril']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Mayo</td>
                    <?php if(count($estudiante->pagos_anio['mayo']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['mayo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['mayo']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['mayo']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Junio</td>
                    <?php if(count($estudiante->pagos_anio['junio']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['junio']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['junio']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['junio']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Julio</td>
                    <?php if(count($estudiante->pagos_anio['julio']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['julio']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['julio']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['julio']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Agosto</td>
                    <?php if(count($estudiante->pagos_anio['agosto']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['agosto']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['agosto']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['agosto']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Septiembre</td>
                    <?php if(count($estudiante->pagos_anio['septiembre']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['septiembre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['septiembre']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['septiembre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Octubre</td>
                    <?php if(count($estudiante->pagos_anio['octubre']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['octubre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['octubre']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['octubre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Noviembre</td>
                    <?php if(count($estudiante->pagos_anio['noviembre']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['noviembre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['noviembre']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['noviembre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Diciembre</td>
                    <?php if(count($estudiante->pagos_anio['diciembre']) > 1): ?>
                        <td class="multiples-pagos" colspan="6">
                            <?php $__currentLoopData = $estudiante->pagos_anio['diciembre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="detalles">
                                    <div class="text-uppercase" style="width: 123px"><?php echo e($pago['documento']); ?></div>
                                    <div style="width: 150px"><?php echo e($pago['num_documento']); ?></div>
                                    <div style="width: 120px"><?php echo e($pago['fecha_pago']); ?></div>
                                    <div style="width: 130px"><?php echo e(toCLP($pago['valor'])); ?></div>
                                    <div class="text-capitalize" style="width: 150px"><?php echo e($pago['forma']); ?></div>
                                    <div style="width: auto"><?php echo e($pago['observacion']); ?></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    <?php elseif(count($estudiante->pagos_anio['diciembre']) == 0): ?>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    <?php else: ?>
                        <?php $__currentLoopData = $estudiante->pagos_anio['diciembre']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <td class="text-center text-uppercase"><?php echo e($pago['documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['num_documento']); ?></td>
                            <td class="text-center"><?php echo e($pago['fecha_pago']); ?></td>
                            <td class="text-center"><?php echo e(toCLP($pago['valor'])); ?></td>
                            <td class="text-center text-capitalize"><?php echo e($pago['forma']); ?></td>
                            <td><?php echo e($pago['observacion']); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tr>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
    function cancelForm() {
        const form = document.getElementById('formPago');
        form.reset();
    }
</script>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\FICOM\resources\views/estudiante/pagos.blade.php ENDPATH**/ ?>