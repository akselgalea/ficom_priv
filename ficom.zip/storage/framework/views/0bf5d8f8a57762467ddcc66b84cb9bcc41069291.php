
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="mb-3">Cursos</h2>
        
        

        <div class="row my-3">
            <?php $__currentLoopData = $cursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-4 mb-3">
                <div class="card curso">
                    <div>
                        <div class="nombre"><?php echo e($curso->curso . '-' . $curso->paralelo); ?></div>
                        <div class="arancel"><b>Arancel:</b> <?php echo e(toCLP($curso->arancel)); ?></div>
                        <div class="cantidad"><b>Cantidad estudiantes:</b> <?php echo e($curso->estudiantes->count()); ?></div>
                    </div>

                    <div class="buttons mt-2">
                        <a href="<?php echo e(route('curso.show', $curso->id)); ?>" class="btn btn-primary">Ver</a>
                        <?php if(Auth::user()->hasAnyRole('admin', 'contabilidad')): ?>
                            <a href="<?php echo e(route('curso.edit', $curso->id)); ?>" class="btn btn-primary">Editar</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\FICOM\resources\views/curso/index.blade.php ENDPATH**/ ?>