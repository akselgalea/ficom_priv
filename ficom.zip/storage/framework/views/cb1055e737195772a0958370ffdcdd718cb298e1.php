
<?php $__env->startSection('content'); ?>
<?php if(session('res') && session('res')['status'] == 400) $cursoErr = session('res')['cursoErr']; ?>

<div class="container card form-container">
    <form method="post" action="<?php echo e(route('curso.update', $curso->id)); ?>" id="formCurso" class="mt-3 row">
        <?php echo csrf_field(); ?>
        <h2 class="form-title"><?php echo e($curso->curso . '-' . $curso->paralelo); ?></h2>
        
        <div class="form-group mb-3 col-12">
            <label class="form-label" for="arancel">Arancel</label>
            <input type="number" class="form-control" id="arancel" name="arancel" value="<?php echo e(isset($cursoErr) ? $cursoErr['arancel'] : $curso->arancel); ?>" disabled />
        </div>

        <?php if(Auth::user()->hasAnyRole('admin', 'contabilidad')): ?>
            <div class="buttons">
                <button type="button" id="btn-editar" class="btn btn-secondary" onclick="editar()">Editar</button>
                <button type="button" id="btn-cancelar" class="btn btn-danger" onclick="cancelEditar()" hidden>Cancelar</button>
                <button type="submit" id="btn-enviar" class="btn btn-primary" hidden>Guardar</button>
            </div>
        <?php endif; ?>
    </form>
</div>

<div class="container card mt-3" id="table">
    <h2>Estudiantes</h2>
    <?php if($curso->estudiantes->count() == 0): ?>   
        <p>Este curso no tiene estudiantes en nuestros registros</p>
    <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">Apellidos</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">RUN</th>
                    <th scope="col">Prioridad</th>
                    <th scope="col">Curso</th>
                    <th scope="col">Opciones</th>
                </tr>
            </thead>
            <tbody class="table-group-divider">
                <?php $__currentLoopData = $curso->estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estud): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr 
                        <?php switch($estud->prioridad):
                            case ('alumno regular'): ?>
                                class="table-light"
                                <?php break; ?>
                        
                            <?php case ('prioritario'): ?>
                                class="table-danger"
                                <?php break; ?>
                    
                            <?php case ('nuevo prioritario'): ?>
                                class="table-primary"
                                <?php break; ?>
                        <?php endswitch; ?>
                    >
                        <td><?php echo e($estud->apellidos); ?></td>
                        <td><?php echo e($estud->nombres); ?></td>
                        <td><?php echo e($estud->rut . '-' . $estud->dv); ?></td>
                        <td class="flc"><?php echo e($estud->prioridad); ?></td>
                        <td>
                            <?php if(isset($estud->curso)): ?>
                                <?php echo e($estud->curso->curso . '-' . $estud->curso->paralelo); ?>

                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo e(route('estudiante.show', $estud->id)); ?>" class="btn btn-primary" data-bs-toggle="tooltip" title="Perfil del estudiante">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                                    class="bi bi-person-fill" viewBox="0 0 16 16">
                                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3Zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z" />
                                </svg>
                            </a>
                            <a href="<?php echo e(route('estudiante.pagos', $estud->id)); ?>" class="btn btn-secondary" data-bs-toggle="tooltip" title="Pagos del estudiante">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-list" viewBox="0 0 16 16">
                                    <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
                                    <path d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm-1-5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zM4 8a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm0 2.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0z"/>
                                </svg>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<style lang="scss">
    div.container#table {
        min-height: 500px
    }
    tr {vertical-align: middle}
    
    .buscador {
        width: 100%;
        display: flex;
        justify-content: flex-end;
        gap: .5rem;
        margin-bottom: 1rem;
    }
</style>

<script>
    const btneditar = document.getElementById('btn-editar');
    const cancelar = document.getElementById('btn-cancelar');
    const enviar = document.getElementById('btn-enviar');

    //Campos
    const arancel = document.getElementById('arancel');
    
    function editar() {
        btneditar.hidden = true;
        cancelar.hidden = false;
        enviar.hidden = false;
        enableInput();
    }

    function cancelEditar() {
        btneditar.hidden = false;
        cancelar.hidden = true;
        enviar.hidden = true;
        disableInput();
    }

    function enableInput() {
        arancel.disabled = false;
    }

    function disableInput() {
        arancel.disabled = true;
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\proyectos\FICOM\resources\views/curso/mostrar.blade.php ENDPATH**/ ?>